package com.springboot.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Candidate;

import com.springboot.Exception.CandidatenotFoundException;
import com.springboot.repository.CandidateRepository;
import com.springboot.service.CandidateServices;



@RestController
@RequestMapping("Candidate")
public class CandidateController {
	
	@Autowired
	private CandidateServices candidateServices;
	@Autowired
	
	private CandidateRepository candidateRepository;
	
	
	@PostMapping("/addCandidate")
    public ResponseEntity<String> createCandidate(@RequestBody Candidate candidate) {

        try {
        	candidateServices.createCandidate(candidate);
        } catch (CandidatenotFoundException c) {
            // TODO Auto-generated catch block
            c.printStackTrace();
        }
        return new ResponseEntity<>("Candidate  Added", HttpStatus.OK);
	}


	@GetMapping("/findAllCandidates")
	public List<Candidate> getCandidates() {
		return candidateRepository.findAll();
	}

}
