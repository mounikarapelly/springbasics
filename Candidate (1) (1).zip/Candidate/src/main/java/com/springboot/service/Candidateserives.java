package com.springboot.service;

import com.model.Candidate;
import com.springboot.Exception.CandidatenotFoundException;

public interface Candidateserives {

	boolean createCandidate(Candidate candidate) throws CandidatenotFoundException;
	

}
