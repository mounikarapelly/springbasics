package com.model;




import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "candidates")
public class Candidate {

	@Id
	
	
	private String candidateName;	
	private String contactNumber;
	private char  gender;
	private String positionApplied;
	private double expectedSalary;
	private int yearsOfExperience;
	
	
	
	
	
	public Candidate() {
		super();
		this.candidateName = candidateName;
		this.contactNumber = contactNumber;
		this.gender = gender;
		this.positionApplied = positionApplied;
		this.expectedSalary = expectedSalary;
		this.yearsOfExperience = yearsOfExperience;
	}
	public String getCandidateName() {
		return candidateName;
	}
	public void setCandidateName(String candidateName) {
		this.candidateName = candidateName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getPositionApplied() {
		return positionApplied;
	}
	public void setPositionApplied(String positionApplied) {
		this.positionApplied = positionApplied;
	}
	public double getExpectedSalary() {
		return expectedSalary;
	}
	public void setExpectedSalary(double expectedSalary) {
		this.expectedSalary = expectedSalary;
	}
	public int getYearsOfExperience() {
		return yearsOfExperience;
	}
	public void setYearsOfExperience(int yearsOfExperience) {
		this.yearsOfExperience = yearsOfExperience;
	}
	@Override
	public String toString() {
		return "Candidate [candidateName=" + candidateName + ", contactNumber=" + contactNumber + ", gender=" + gender
				+ ", positionApplied=" + positionApplied + ", expectedSalary=" + expectedSalary + ", yearsOfExperience="
				+ yearsOfExperience + "]";
	}
	
	



	
	
	
	
	
}
