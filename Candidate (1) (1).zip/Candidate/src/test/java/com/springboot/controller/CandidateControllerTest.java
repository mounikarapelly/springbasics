package com.springboot.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.model.Candidate;
import com.springboot.repository.CandidateRepository;
import com.springboot.service.CandidateServices;

import net.bytebuddy.agent.VirtualMachine.ForHotSpot.Connection.Response;
@WebMvcTest(CandidateController.class)
public class CandidateControllerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private CandidateServices service;
	
	@MockBean
	private  CandidateRepository  candidateRepository;
	
	@Test
	public void testcreateCandidate() throws Exception {
		Candidate cand = new Candidate();
		
		cand.setCandidateName("manoj");
		cand.setContactNumber("7382383");
		cand.setPositionApplied("TL");
		cand.setExpectedSalary(343535);
		cand.setYearsOfExperience(4);
		
		
		String inputInjson = this.mapToJson(cand);
		String URI ="/Candidate/addCandidate";
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders

				.post(URI)
				.accept(MediaType.APPLICATION_JSON).content(inputInjson)
				.contentType(MediaType.APPLICATION_JSON);
		
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		MockHttpServletResponse response = result.getResponse();
				
		String outputinJson = response.getContentAsString();
		
		assertThat(outputinJson).isEqualTo(outputinJson);
	    assertEquals(HttpStatus.OK.value(), response.getStatus());
	}

	private String mapToJson(Candidate cand) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
