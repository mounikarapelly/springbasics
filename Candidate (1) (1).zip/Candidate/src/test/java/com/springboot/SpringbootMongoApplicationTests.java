package com.springboot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.annotation.Order;
import org.springframework.test.context.junit4.SpringRunner;

import com.model.Candidate;


@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringbootMongoApplicationTests {

	@Test
	public void contextLoads() {
	}

	@Test
	@Order(1)
	public void testCreate () {
		Candidate c = new Candidate();
		c.setCandidateName("manoj");
		c.setContactNumber("23523");
		c.setPositionApplied("TL");
		c.setExpectedSalary(23582);
		c.setYearsOfExperience(2);
	
}
	
	
}