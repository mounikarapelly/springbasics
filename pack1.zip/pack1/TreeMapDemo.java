package pack1;

import java.util.LinkedHashMap;
import java.util.TreeMap;

public class TreeMapDemo {

	public static void main(String[] args) {
		 TreeMap<Object, Object> treeMap = new TreeMap<>();
			
		 treeMap.put(8, "mouni");
		// treeMap.put(null, "mmm");
		// treeMap.put(18, "NNN");
		 treeMap.put(8, "AA");
		 treeMap.put(100, "mouni");
		// treeMap.put(1, null);
		// treeMap.put(20, null);
		 treeMap.put(2, "mouni");
		// treeMap.put(null, "AAA");
		
		 
		 
				System.out.println(treeMap);

	}

}
