package pack1;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		//list allows duplicate oredrS
		//insertion order follows
		//Arraylist,linkedlist,vector
		//arraylist works on index postion
		//al adjustable in size
		//it is mailny used retry the already storage elements
		

		ArrayList<Object> arrayListDemo = new ArrayList<Object>();
		
		arrayListDemo.add("data");
		arrayListDemo.add(1);
		arrayListDemo.add("data");
		arrayListDemo.add('A');
		arrayListDemo.add(null);
		arrayListDemo.add(true);
		arrayListDemo.add(false);
		arrayListDemo.add(true);
		arrayListDemo.add('A');
		System.out.println(arrayListDemo);
		

		

	}

}
