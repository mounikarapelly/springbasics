package pack1;

import java.util.HashMap;

public class HashmapDemo {

	public static void main(String[] args) {
        //map follows the key-value pair
		//it follows the hashing mechanism
		//it doesn't allow the duplicate
		//hashmap,treemap,inkedhashmap,hashtable
		//hash map doesnt follow insertion oredr
		//keys doesn't allow duplicate,but values allow duplicate
		//if  i give 2 dupicate keys and 2 different values, 1st value will not print ,2nd key and value it will aceept
		HashMap<Object, Object> hashMap = new HashMap<>();

		hashMap.put(8, "mouni");
		hashMap.put(null, "mmm");
		hashMap.put(18, "NNN");
		hashMap.put(8, "AA");
		hashMap.put(100, "mouni");
		hashMap.put(1, null);
		hashMap.put(20, null);
		hashMap.put(2, "mouni");
		hashMap.put(null, "AAA");
		System.out.println(hashMap);
	}

}
