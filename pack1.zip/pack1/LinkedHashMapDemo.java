package pack1;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class LinkedHashMapDemo {

	public static void main(String[] args) {
		
		//same as Hashmap
		//it follows insertion order
    LinkedHashMap<Object, Object> linkedHashMap = new LinkedHashMap<>();
		
    linkedHashMap.put(8, "mouni");
    linkedHashMap.put(null, "mmm");
    linkedHashMap.put(18, "NNN");
    linkedHashMap.put(8, "AA");
    linkedHashMap.put(100, "mouni");
    linkedHashMap.put(1, null);
    linkedHashMap.put(20, null);
    linkedHashMap.put(2, "mouni");
    linkedHashMap.put(null, "AAA");
		System.out.println(linkedHashMap);

	}

}
