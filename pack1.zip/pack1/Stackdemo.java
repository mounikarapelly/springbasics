package pack1;

import java.util.Stack;

public class Stackdemo {

	public static void main(String[] args) {
		Stack s= new Stack();
		s.push(1);
		s.push(2);
		s.push(3);
		s.push(4);
		s.push(5);
		s.push(6);
		s.push(7);
		s.push(8);
		s.push(9);//push method insert the elemts
		System.out.println(s);
		s.pop();//pop method removes last element
		System.out.println(s);
		System.out.println(s.peek());//peek method reads the top of the elemnt
		System.out.println(s.empty());//if elemts is there it will print fals.ow false
		System.out.println(s.search(4));//seacrch method specific elemnt print
		System.out.println();

	}

}
