package pack1;

import java.util.Iterator;
import java.util.LinkedList;

public class LinkedListDemo {
	//it is used doblelinkedlist,it stores the value
	//
	//it isa mainly followa insertion deletion

	public static void main(String[] args) {
		
		LinkedList<Student> m1= new LinkedList<>();
		m1.add(new Student(1,"mounika","HYD",999999990));
		Student m2= new Student(2,"Sree","HYD",979797979);
		m1.add(m2);
		Iterator<Student> it= m1.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		System.out.println();

	}

}
