package pack1;

import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		//treeset follows assecending order 
		//it follows homogenous data 
		TreeSet<Object> treeSet = new TreeSet<>();
		treeSet.add("c");
		treeSet.add("a");
		treeSet.add("z");
		treeSet.add("Z");
		treeSet.add("k");
		treeSet.add("o");
		treeSet.add("Z");
	
		System.out.println(treeSet);
		TreeSet<Object> treeSet1 = new TreeSet<>();
		treeSet1.add(10);
		treeSet1.add(18);
		treeSet1.add(1);
		treeSet1.add(15);
		treeSet1.add(10);
		treeSet1.add(99);
		System.out.println(treeSet1);
		


	}

}
