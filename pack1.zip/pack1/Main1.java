package pack1;

public class Main1 {

	public static void main(String[] args) {
		int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
		int sum = 0;
		int smallest = array[0];
		int highest = array[0];
		for (int i = 0; i < 2; i++) {
		    for (int j = 0; j < 10; j++) {
		      
		        sum += array[j];
		        if (array[j] < smallest) {
		            smallest = array[j];
		        }
		        if (array[j] > highest) {
		            highest = array[j];
		        }
		    }
		}
		System.out.println("Sum of the array: " + sum);
		System.out.println("Smallest value in the array: " + smallest);
		System.out.println("Highest value in the array: " + highest);


	}

}
