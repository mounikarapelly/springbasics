package pack1;

import java.util.HashSet;

public class Hashsetdemo {
	//set internally follows hashing mechanism
	//hashset doesn't follow any insertion order
	//it will not allow dupicate value

	public static void main(String[] args) {
		HashSet<Object> hashSet = new HashSet<>();
		hashSet.add(10);
		hashSet.add("aa");
		hashSet.add("bbb");
		hashSet.add("aa");
		hashSet.add(10);
		hashSet.add(null);
		hashSet.add(null);
		hashSet.add(false);
		hashSet.add(20);
		System.out.println(hashSet);
	
	}

}
