package pack1;

import java.util.LinkedHashSet;

public class Linkedsetdemo {

	public static void main(String[] args) {
		LinkedHashSet<Object> linkedHashSet = new LinkedHashSet<>();
		linkedHashSet.add("aaaa");
		linkedHashSet.add("AAA");
		linkedHashSet.add(1);
		linkedHashSet.add(null);
		linkedHashSet.add(1);
		linkedHashSet.add(null);
		linkedHashSet.add("aaa");
		linkedHashSet.add('a');
		linkedHashSet.add('a');
		linkedHashSet.add(false);
		System.out.println(linkedHashSet);

	}

}
