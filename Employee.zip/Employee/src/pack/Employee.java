package pack;

import java.util.LinkedList;

public class Employee {
	
	 public static int Salary;
	private int employeeId;
	 private String employeeName;
	 static int salary;
	 private int experience;
	public Employee(int employeeId, String employeeName, int salary, int experience) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.setSalary(salary);
		this.experience = experience;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + getSalary()
				+ ", experience=" + experience + "]";
	}
	
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

	class LinkedListEmptyException extends RuntimeException{
	       public LinkedListEmptyException(){
	         super();
	       }
	      
	     public LinkedListEmptyException(String message){
	         super(message);
	       }  
	}


}
