package pack;

public class Emplyoee1 {
	
	private static int Salary = 0;

	public static void main(String args[]) {
    	//Creating object of EmployeeDetails class  
    	EmployeeDetials emp = new EmployeeDetials();
    	 //Setting values to the properties  
    	emp.setEmployeeId(101);
    	emp.setEmployeeName("mounika");
    	emp.setSalary(10000);
    	emp.setExperience(2);
    	System.out.println(emp);
    	
    	
    	//Getting salary using getter  
        int sal = emp.getSalary();  
        int increment = 0;  
        //Incrementing salary based on condition  
        if ((sal >=1000) && (sal <=5000))  
        {  
            //incrementing salary 15%  
            increment += (sal * 15)/100;  
            sal = sal+increment;  
              
            emp.setSalary(sal);  
            System.out.println("\n Salary is incremented \n");  
            System.out.println(emp);  
              
        }else if ((sal >=6000) && (sal <=10000)){  
            //incrementing salary 30%  
            increment += (sal * 30)/100;  
            sal = sal+increment;  
              
            emp.setSalary(sal);  
            System.out.println("\n Salary is incremented \n");  
            System.out.println(emp);  
        }else if ((sal >=11000) && (sal <=15000)){  
            //incrementing salary 45%  
            increment += (sal * 45)/100;  
            sal = sal+increment;  
              
            emp.setSalary(sal);  
            System.out.println("\n Salary is incremented \n");  
            System.out.println(emp);  
        }
        
        else {  
            System.out.println("\n Salary is not incremented \n");  
            System.out.println(emp);  
        }         
    }  

}
