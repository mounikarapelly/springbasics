package pack;

public class Emplyoee {
			  
		    public static void main(String args[]) {
		    	//Creating object of EmployeeDetails class  
		    	EmployeeDetials emp = new EmployeeDetials();
		    	 //Setting values to the properties  
		    	emp.setEmployeeId(101);
		    	emp.setEmployeeName("mounika");
		    	emp.setSalary(12000);
		    	emp.setExperience(5);
		    	System.out.println(emp); 
		    	
		    	int experience = 0;
		    	Object increment = null;
				calculateIncrementSalary(increment);
				int incrementedSalary;
		    	
		    	int exp = emp.getExperience();
		    	
				if(exp >=1 && exp <=5) {
		    		   
		    		    int incrementPercentage=15;
						
						incrementedSalary=Employee.Salary+((Employee.salary*incrementPercentage)/100);	
		             //   exp = exp+incrementPercentage;  
		                emp.setSalary(exp);  
		                System.out.println("\n Salary is incremented \n");  
		                System.out.println(emp);  
		    		   
		    		    }
		    		     else if(exp >=6 && exp <=10) {
		    		    	int incrementPercentage = 30;
		    		    	
		    		    	incrementedSalary=Employee.salary+((Employee.salary*incrementPercentage)/100);	
		                    exp = exp+incrementPercentage;  
		                    emp.setSalary(exp);  
		                    System.out.println("\n Salary is incremented \n");  
		                    System.out.println(emp);
		    		    	
		    		    
		    		    }  else if(exp >=11 && exp <=15) {
		    		    	int incrementPercentage = 45;
		    		    	
							incrementedSalary=Employee.Salary+((Employee.Salary*incrementPercentage)/100);	
		                    exp = exp+incrementPercentage;  
		                    emp.setSalary(exp);  
		                    System.out.println("\n Salary is incremented \n");  
		                    System.out.println(emp);
		    		    } 
		    		    else {
		    		    	
		    		    	System.out.println("\n Salary is not incremented \n");  
		    	            System.out.println(emp); 
		    		    return ;
		    		    }
				
		    	
      }

			private static void calculateIncrementSalary(Object increment) {
				
				
			}

			    

			
			
 }


