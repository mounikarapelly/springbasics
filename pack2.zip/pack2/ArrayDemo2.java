package pack2;

public class ArrayDemo2 {

	public static void main(String[] args) {
		// create an array
		   int[] j = {12, 4, 5};

		   // loop through the array
		   // using for loop
		   System.out.println("Using for Loop:");
		   for(int i = 0; i < j.length; i++) {
		     System.out.println(j[i]);
		   }
	}

}
