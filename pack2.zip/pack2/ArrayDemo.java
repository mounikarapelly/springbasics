package pack2;

public class ArrayDemo {

	public static void main(String[] args) {
		
		 // create an array
		   int[] i = {12, 4, 5, 2, 5};

		   // access each array elements
		   System.out.println("Accessing Elements of Array:");
		   System.out.println("First Element: " + i[0]);
		   System.out.println("Second Element: " + i[1]);
		   System.out.println("Third Element: " + i[2]);
		   System.out.println("Fourth Element: " + i[3]);
		   System.out.println("Fifth Element: " + i[4]);
		 }


	

}
